import React from 'react';
import {  TextInput } from 'react-native';
import { MdEdit, MdHighlightOff} from "react-icons/md";
import { Link } from "react-router-dom";
import { BsGrid3X3 } from "react-icons/bs";
import DataTable from 'react-data-table-component';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
import { HiUserCircle } from "react-icons/hi";
import { GoSearch } from "react-icons/go";
import Select from 'react-select'
import "typeface-open-sans"
import axios from 'axios'

import _ from 'lodash'
import { API_URL } from '../../config'
import Modal from 'react-modal';
import './style.css' //this is our css
import NavBar from '.././navbar'
import toast, { Toaster } from 'react-hot-toast';
import ReactTooltip from 'react-tooltip';
import { ConsoleHelper, networkError, updatedSuccessfully } from '../Common'

//import S3 from 'aws-sdk/clients/s3';
const customStyles2 = {
title: {
  style: {
    fontColor: 'red',
    fontWeight: '900',

  }
},
rows: {
  style: {
    minHeight: '52px', // override the row height

  }
},
headCells: {
  style: {
    fontFamily: "Qualcomm Next",
    textTransform: 'uppercase',

    backgroundColor:'#eeeeee',
    paddingLeft: '0 8px'
  },
},
headRow: {
   style: {
     minHeight: '40px',


     borderRadius:8

   },
 },
cells: {
  style: {
    border:1,
    paddingLeft: '0 8px',
    fontFamily: "Qualcomm Next",
  },
},
};

export default class App extends React.Component {
  constructor(props) {
      super(props);
      this.state = {
            loading: true,
            filter_val_dropdown_options : [
            { value: 'project', label: 'project' },
            { value: 'operation', label: 'operation' },
            { value: 'foundry', label: 'foundry' },
            { value: 'test_name', label: 'test_name' },
            { value: 'test_number', label: 'test_number' },
            { value: 'test_type', label: 'test_type' },
            { value: 'unique_gen_kpi_config_id', label: 'unique_gen_kpi_config_id' },
            ],
            filter_val: { value: 'all', label: 'all' },




            changeButton: false,



            pageNumber: 1,
            total_records_per_page: 20, //set by your coice

            editableText: null,
            editableDrop: null,

            editableKpilevel1: null,
            editableKpilevel2: null,
            editableKpilevel3: null,
            editableCategory: null,
            editableCSPerformance: null,
            editableSpec: null,

            enable_ml_config: '',
            enable_pipeline_config: '',
            enable_sql_filter: '',
            category_global: '',
            cs_performance_global: '',
            spec_global: '',


            search_any: '',

            project: '',
            operation: '',
            foundry: '',
            test_name: '',
            test_number: '',
            test_type: '',
            unique_gen_kpi_config_id: '',

            searchOn_extended: false,
            searchOn_normal: false,
            searchCount: null,
            searchTotalCount: 0,

            lot_status_global: '',
            error_cause_global: '',

            updateModal: false,
            columnEditable: null,

            advanceSearch: false,

            editableCheck: {},
            total_editableCheck: 0,

            search: '',
            dataType: [], // what we feed to our table
            allowed: true,
            editableEnable_ml_config: null,
            editableEnable_pipeline_config : null,
            editableEnable_sql_filter : null,
            selectedFile: null



        }
    }

    onFileChange = event => {
      // Update the state
      this.setState({ selectedFile: event.target.files[0] });
    };

    // On file upload (click the upload button)
    onFileUpload = () => {
      // Create an object of formData
      const formData = new FormData();
      // Update the formData object
      formData.append(
        "myFile",
        this.state.selectedFile,
        this.state.selectedFile.name
      );
      // Details of the uploaded file
      console.log(this.state.selectedFile);
      // Request made to the backend api
      // Send formData object
      axios.post(`${API_URL}/onboard_file_uploadfile`, formData);
    }


    // initialization , lifecycle method
    async componentDidMount(){
      try {
        const currentUser = await localStorage.getItem('currentUser')
        this.setState({ currentUser })
        var res = await axios.get(`${API_URL}/userlevel?currentUser=${currentUser}`)
        console.log('res',res)
        if(res!== null && typeof res.data.userlevel !== 'undefined' && typeof res.data.userlevel[0].kpi !== 'undefined' && res.data.userlevel[0].kpi == 1){
          //console.log('res>>> ',res.data.userlevel[0].kpi)
          //this.setState({ userlevel: res.data.userlevel[0], loadingfeatures: true  })
        }
        else {
          this.setState({ allowed: false })
        }
      } catch(error){
         console.log('')
      }
      this.getData(1)
    }

    setStateAsync(state) {
      return new Promise((resolve) => {
        this.setState(state, resolve)
      });
    }



    // there we fetch data
    async getData(pageNumber){
            let offset = (pageNumber-1) * this.state.total_records_per_page;
            this.setState({ loading: true })
            try{
            var response = await axios.get(`${API_URL}/project_onboarding?offset=${offset}&limit=${this.state.total_records_per_page}`)
            console.log('response',response.data)
            if(response){
              //var dataType = response.data
              // tomorrow-x
              if(response.data.error){
                toast.error(networkError)
                this.setState({ loading: false})
                return
              }
              var dataType = response.data.data
              // tomorrow-x
              // for (const [key, value] of Object.entries(dataType[0])) {
              //     console.log('key',key);
              // }


              var editableCheck = {} //extra object for faster response
              dataType.forEach((item, i) => {
                editableCheck[item.id] = { edit: false, enable_ml_config: item.enable_ml_config, enable_pipeline_config: item.enable_pipeline_config, enable_sql_filter: item.enable_sql_filter,  edited: false }
              });
              this.setState({dataType, editableCheck, total_editableCheck: Object.keys(editableCheck).length, loading: false })
            }
          } catch(error){
            //console.log('error', error)
            toast.error(networkError)
            this.setState({ loading: false})
          }
    }

    // to send to nextPage
    async getNextPage(){
      let pageNumber = this.state.pageNumber + 1
      //console.log('pageNumber',pageNumber)
      if(this.state.searchOn_extended){
        this.searchIt_extended(pageNumber)
      }
      else if(this.state.searchOn_normal){
        this.searchIt(pageNumber)
      }
      else {
        this.getData(pageNumber)
      }
      this.setState({ pageNumber })
    }

    // to send to previousPage
    async getPreviousPage(){
        let pageNumber = this.state.pageNumber - 1
        //console.log('pageNumber',pageNumber)
        if(this.state.searchOn_extended){
          this.searchIt_extended(pageNumber)
        } else if(this.state.searchOn_normal){
            this.searchIt(pageNumber)
        } else {
          this.getData(pageNumber)
        }
        this.setState({ pageNumber })
    }

    DropdownChange1 = (option) => {
      this.setState({ filter_val: option })
    }


    confirmupdate_beforeUpdate(columnValue, columnName, type){

    //console.log('this.state.editableCheck',this.state.editableCheck)

    confirmAlert({
        title:   "Confirm Update",
        message:   `Are you sure want to update ${this.state.total_editableCheck} rows ?`,
        buttons:   [
             {
               label: "Cancel",
               onPress: () => console.log(''),
               style: "cancel"
             },
             { label: "Yes", onClick: () => this.confirmupdateAColumn(columnValue, columnName, type) }
           ],

         });
      }

    confirmupdateAColumn(columnValue, columnName, type){
      //console.log(columnValue, columnName,type)
      this.setState({ updateModal: false })
      var data = []
       _.map(this.state.editableCheck, (each, id) => {
          console.log('each',each,id)
            data.push( { [columnName]: type === 'dropdown' ? this.state[columnValue].value : this.state[columnValue] , id: id  })
      })
      ConsoleHelper('data to update',data)
      //return;
      this.updateServerFinally(data)
    }

    updateColumn(columnName){
      this.setState({ [columnName]: !this.state[columnName] })
    }


    updateSelected(){
      ConsoleHelper('this.state.editableCheck',this.state.editableCheck)

      //return;

      var data = []
       _.map(this.state.editableCheck, (each, id) => {
        if(each.edit === true){
          //data.push( { lot_status: this.state.editableDrop[id] , error_cause: this.state.editableText[id], loh_lot_id: id  })
          //editableCheck[item.KPI_CONFIG_ID] = { edit: false, KPI_LEVEL1: item.KPI_LEVEL1, KPI_LEVEL2: item.KPI_LEVEL2, KPI_LEVEL3: item.KPI_LEVEL3, CATEGORY: item.CATEGORY, CS_PERFORMANCE: item.CS_PERFORMANCE, SPEC: item.SPEC, edited: false }

          data.push({
            enable_ml_config: this.state.editableEnable_ml_config[id] === null ? '' : this.state.editableEnable_ml_config[id],
            enable_pipeline_config: this.state.editableEnable_pipeline_config[id] === null ? '' : this.state.editableEnable_pipeline_config[id],
            enable_sql_filter: this.state.editableEnable_sql_filter[id] === null ? '' : this.state.editableEnable_sql_filter[id],
            id: id
          })

        }
      })

      console.log('data>',data)

      confirmAlert({
        title: 'Confirm Update',
        message:   `Are you sure want to update ${data.length} rows ?`,
        buttons: [
          {
            label: 'Yes',
            onClick: () => this.updateServerFinally(data)
          },
          {
            label: 'No',
            onClick: () => { console.log('') }
          }
        ]
      });

      ConsoleHelper('data',data)
      //this.updateServerFinally(data)
    }

    updateServerFinally(data){
      this.setState({ loading: true })
      console.log('data to update',data)
      axios.post(`${API_URL}/update_multi_project_onboarding`, {data, currentUser: this.state.currentUser })
      .then((response)=> {
          // tomorrow-x
          if(response.error){
            toast.error(networkError)
            this.setState({ loading: false })
            return
          }
          // tomorrow-x
          if(typeof response.data !== 'undefined' && typeof response.data.status !== 'undefined' && response.data.status){
              //   var editableCheck = this.state.editableCheck
              //   editableCheck[id].edit = !editableCheck[id].edit
              //   this.setState({ editableCheck })
              this.getData(this.state.pageNumber)
              this.setState({  loading: false })
              toast.success(updatedSuccessfully)
          }
      }).catch(error => {
          ConsoleHelper('error',error)
          toast.error(networkError)
          this.setState({ loading: false })
      })
    }

  async searchIt(pageNumber){
      //console.log('searchIt',searchIt)
      let offset = (pageNumber-1) * this.state.total_records_per_page;

      // if search field is blank
      if(String(this.state.search).trim() == ''){
          console.log('search filter',this.state.filter_val.value)
          if(this.state.filter_val.value !== 'all'){
            this.setState({dataType: [], editableCheck: {}, total_editableCheck: 0, loading: false })
          }
          else {
            this.setState({ pageNumber: 1, searchOn_extended: false, searchOn_normal: false })
            this.getData(1)
          }
          return
      }


      var data = {
        search_type: String(this.state.filter_val.value).toUpperCase(),
        search: this.state.search,
        limit: this.state.total_records_per_page,
        offset
      }
      console.log('data',data)
      this.setState({ searchOn_extended: false, searchOn_normal: true, loading: true })
      try {

        const notifications = await axios.request({
                          method: 'GET',
                          url: `${API_URL}/search_kpi`,
                          params: data,
                          responseType: 'arraybuffer',
                          reponseEncoding: 'binary'
                          });
          const decoder = new TextDecoder('ISO-8859-1');
          let response = decoder.decode(notifications.data)
          console.log('response',response)
          response = JSON.parse(response)
          console.log('response',response)

          // tomorrow-x
          if(typeof response.error !== 'undefined' && response.error){
            toast.error(networkError)
            this.setState({ loading: false })
            return
          }
          // tomorrow-x

          //var response = await axios.get(`${API_URL}/search_lohlot?search_type=${this.state.filter_val.value}&search=${this.state.search}`)
          //console.log('response',response.data)
          if(typeof response !== 'undefined' && typeof response.status !== 'undefined' && response.status){
            //this.getData(1)
            console.log('then what happens')
            var dataType = response.data

            for (const [key, value] of Object.entries(dataType[0])) {
                console.log('key',key);
            }


              var editableCheck = {}
              dataType.forEach((item, i) => {
                editableCheck[item.id] = { edit: false, enable_ml_config: item.enable_ml_config, enable_pipeline_config: item.enable_pipeline_config,enable_sql_filter: item.enable_sql_filter, edited: false }
                //editableCheck[item.loh_lot_id] = { edit: false, error_cause: item.error_cause, lot_status: item.lot_status, edited: false }
              });
              console.log('this.state.searchOn_normal',this.state.searchOn_normal)
              this.setState({dataType, editableCheck, total_editableCheck: Object.keys(editableCheck).length, searchCount: response.count, searchTotalCount: response.total_count, loading: false })
          }
        } catch(error){
          this.setState({ loading: false })
          toast.error(networkError)
          ConsoleHelper('error', error)
        }
  }



  async searchIt_extended(pageNumber){

    let offset = (pageNumber-1) * this.state.total_records_per_page;

    var search_any = String(this.state.search_any).trim()
    var project = String(this.state.project).trim()
    var operation = String(this.state.operation).trim()
    var foundry = String(this.state.foundry).trim()
    var test_name = String(this.state.test_name).trim()
    var test_number = String(this.state.test_number).trim()
    var test_type = String(this.state.test_type).trim()
    var unique_gen_kpi_config_id = String(this.state.unique_gen_kpi_config_id).trim()

    if(search_any.length < 1 && project.length < 1 && operation.length < 1 && foundry.length < 1 && test_name.length < 1 && test_number.length < 1  && test_type.length < 1 && unique_gen_kpi_config_id.length < 1  ){
      this.setState({ pageNumber: 1, searchOn_extended: false, searchOn_normal: false })
      this.getData(1)
      return
    }


    // var data = `search_any=${search_any}&loh_lot_id=${loh_lot_id}&facility=${facility}&operation=${operation}&lot_id=${lot_id}&correlation_id=${correlation_id}&
    // file_id=${file_id}&lot_status=${lot_status}&error_cause=${error_cause}&offset=${offset}&project=${project}&limit=${this.state.total_records_per_page}`
    var data = {
      search_any,
      project,
      operation,
      foundry,
      test_name,
      test_number,
      test_type,
      unique_gen_kpi_config_id,
      offset,
      limit: this.state.total_records_per_page
    }
    console.log('data to send',data)
    this.setState({ searchOn_extended: true, searchOn_normal: false, loading: true })
      try {
          //var response = await axios.get(`${API_URL}/search_lohlot_extended?${data}`)
          const notifications = await axios.request({
                            method: 'GET',
                            url: `${API_URL}/search_kpi_extended`,
                            params: data,
                            responseType: 'arraybuffer',
                            reponseEncoding: 'binary'
                            });
        const decoder = new TextDecoder('ISO-8859-1');
        let response = decoder.decode(notifications.data)
        // tomorrow-x
        // tomorrow-x
        console.log('response',response)
        response = JSON.parse(response)
        console.log('response',response)
        if(typeof response.error !== 'undefined' && response.error){
          toast.error(networkError)
          this.setState({ loading: false })
          return
        }


          if(typeof response !== 'undefined' && typeof response.status !== 'undefined' && response.status){
            console.log('we got data successfully')
            var dataType = response.data
              var editableCheck = {}
              dataType.forEach((item, i) => {
                //editableCheck[item.loh_lot_id] = { edit: false, error_cause: item.error_cause, lot_status: item.lot_status, edited: false }
                //editableText[item.loh_lot_id] =  item.error_cause
                editableCheck[item.id] = { edit: false, enable_ml_config: item.enable_ml_config, enable_pipeline_config: item.enable_pipeline_config, enable_sql_filter:item.enable_sql_filter, edited: false }
              });
              this.setState({dataType, editableCheck, total_editableCheck: Object.keys(editableCheck).length, searchCount: response.count, searchTotalCount: response.total_count, loading: false })
          }
        } catch(error){
          //console.log('error', error)
          toast.error(networkError)
          this.setState({ loading: false })
        }
  }

  // I should rename it clearSearch from advanceSearch
  clearsearch_extended(){
    this.setState({ searchOn_extended: false, search_any: '', project: '', operation: '', foundry: '', test_name: '', test_number: '' , test_type: '', unique_gen_kpi_config_id: ''  })
    this.getData(1)
  }


  render() {



    const columns = [

      {
          name:<h3></h3>,
          sortable: false,
          width: "30px",
          cell: (row) => {
            //console.log('hey do you re-render ',this.state.editableCheck[row.loh_lot_id].edit)
            return(
              <>
              <div>
                   <input type="checkbox"
                     checked={this.state.editableCheck[row.id].edit}

                     onChange={() => {
                         var editableCheck = this.state.editableCheck;
                         editableCheck[row.id].edit = !editableCheck[row.id].edit;

                         var editableEnable_ml_config = this.state.editableEnable_ml_config !== null ? this.state.editableEnable_ml_config : { }
                         var editableEnable_pipeline_config = this.state.editableEnable_pipeline_config !== null ? this.state.editableEnable_pipeline_config : { }
                         var editableEnable_sql_filter = this.state.editableEnable_sql_filter !== null ? this.state.editableEnable_sql_filter : { }


                         if(editableCheck[row.id].edit){

                           console.log('this.state.editableEnable_ml_config',this.state.editableEnable_ml_config, typeof(this.state.editableEnable_ml_config), this.state.editableEnable_ml_config !== null )


                           console.log('editableCheck 1',editableCheck, editableEnable_ml_config, editableEnable_pipeline_config, editableEnable_sql_filter);

                           editableEnable_ml_config[row.id] = editableCheck[row.id].enable_ml_config
                           editableEnable_pipeline_config[row.id] = editableCheck[row.id].enable_pipeline_config
                           editableEnable_sql_filter[row.id] = editableCheck[row.id].enable_sql_filter

                         }
                         else {
                           console.log('deleting',row.id, editableEnable_ml_config)
                           delete(editableEnable_ml_config[row.id])
                           delete(editableEnable_pipeline_config[row.id])
                           delete(editableEnable_sql_filter[row.id])
                         }

                       console.log('editableCheck 2',editableCheck, editableEnable_ml_config, editableEnable_pipeline_config, editableEnable_sql_filter);
                       this.setState({ editableCheck, editableEnable_ml_config, editableEnable_pipeline_config, editableEnable_sql_filter  })
                     }}



                   />
               </div>
              </>


            )
          }

        },


       {
            name:<h3 class='table-header'>id</h3>,
            sortable: true,
            width: "200px",
            cell: (row) => {
                return(
                      <div class='tabel-column'>{row.id}</div>
                )
            }

        },


            {
                name:<h3 class='table-header'>project</h3>,
                sortable: true,
                cell: (row) => {
                return(
                    <div class='tabel-column'>{row.project}</div>
                  )
                }
            },


          {
              name:<h3 class='table-header'>operation</h3>,
              sortable: true,
              cell: (row) => {
                return(
                    <div class='tabel-column'>{row.operation}</div>
                )
              }
            },


            {
                name: <button onClick={()=>this.setState({ updateModal: true, columnEditable: 'enable_ml_config'  })} class='btn-class'><h3 class='editable-column'>enable_ml_config</h3></button>,
                sortable: true,
                width: "100px",
                cell: (row) => {
                  return(
                    <div>
                    {this.state.editableCheck[row.id].edit === false ? (
                      <div class='tabel-column'>{row.enable_ml_config}</div>
                    )
                    :
                    (
                      <input type="text" maxlength="1" value={this.state.editableEnable_ml_config[row.id]} onChange={event => {  var editableEnable_ml_config = this.state.editableEnable_ml_config; editableEnable_ml_config[row.id] = event.target.value; this.setState({ editableEnable_ml_config })  }} class='edit-input' />
                    )}
                    </div>
                  )
                }

              },

          {
            name: <button onClick={()=>this.setState({ updateModal: true, columnEditable: 'enable_pipeline_config'  })} class='btn-class'><h3 class='editable-column'>enable_pipeline_config</h3></button>,
            sortable: true,
            width: "280px",
            maxWidth: "280px",
            cell: (row) => {
              return(
                <div>
                {this.state.editableCheck[row.id].edit === false ? (
                  <div class='tabel-column'>{row.enable_pipeline_config}</div>
                )
                :
                (
                  <input type="text" maxlength="1" value={this.state.editableEnable_pipeline_config[row.id]} onChange={event => {  var editableEnable_pipeline_config = this.state.editableEnable_pipeline_config; editableEnable_pipeline_config[row.id] = event.target.value; this.setState({ editableEnable_pipeline_config })  }} class='edit-input' />
                )}
                </div>
              )
            }

          },

          {
            name: <button onClick={()=>this.setState({ updateModal: true, columnEditable: 'enable_sql_filter'  })} class='btn-class'><h3 class='editable-column'>enable_sql_filter</h3></button>,
            sortable: true,
            width: "200px",
            maxWidth: "200px",
            cell: (row) => {
              return(
                <div>
                {this.state.editableCheck[row.id].edit === false ? (
                  <div class='tabel-column'>{row.enable_sql_filter}</div>
                )
                :
                (
                  <input type="text" maxlength="1" value={this.state.editableEnable_sql_filter[row.id]} onChange={event => {  var editableEnable_sql_filter = this.state.editableEnable_sql_filter; editableEnable_sql_filter[row.id] = event.target.value; this.setState({ editableEnable_sql_filter })  }} class='edit-input' />
                )}
                </div>
              )
            }

          },


  ];

    if(this.state.allowed === false){
      return (
        <div>Unauthorised Access</div>
      )
    }

    return (
      <div>
          <NavBar />

          <div style={{ display: 'flex', flexDirection: 'column', height: 100, backgroundColor: '#3253DC', justifyContent: 'center', marginTop: 5, marginBottom: 20 }}>
            <p style={{ fontSize: 24, fontFamily: "Qualcomm Next", color: 'white', marginLeft: 20 }}>Project Onboarding</p>
          </div>


            <div style={{flexDirection:'row', display:'flex', alignItems:'center'}}>


            <div style={{justifyContent:'flex-end', flex:1,display:'flex', marginRight:20 }}>
            {/*
            <button onClick={()=> this.setState({addkpiDataModal : true})} style={{display:'flex', borderWidth:0,cursor:'pointer', textDecoration:'none',backgroundColor: '#3253DC',height: 40,  alignItems:'center', justifyContent:'center',}}>
            <p style={{fontSize:'14px', fontFamily:'Open Sans',paddingLeft:10, paddingRight:10, color:'white' }}>Import Data</p>
            </button>


            <Link to ="/Add_Kpi"  class='link'>
            <button  style={{display:'flex', borderWidth:0,cursor:'pointer', textDecoration:'none',backgroundColor: '#3253DC',height: 40,  alignItems:'center', justifyContent:'center',}}>
            <p style={{fontSize:'14px', fontFamily:'Open Sans',paddingLeft:10, paddingRight:10, color:'white' }}>Import Data</p>
            </button>
            </Link>
              */}
            </div>
            </div>


            {/*


            {!this.state.advanceSearch && (
            <div style={{flex:1, justifyContent:'center', alignItems:'center', display:'flex', paddingBottom: 20 }}>
                <div class='dropdownContainer'>
                        <div class='selectContainer'>
                                <Select
                                    menuPortalTarget={document.body}
                                    menuPosition={'fixed'}
                                    styles={{
                                    // Fixes the overlapping problem of the component
                                    control: provided => ({ ...provided,  borderWidth:0, fontFamily:'Open Sans', width: '150px'}),
                                    menu: provided => ({ ...provided, zIndex: 9999 ,  fontFamily:'Open Sans'})
                                    }}
                                    options={this.state.filter_val_dropdown_options}
                                    onChange={this.DropdownChange1}
                                    value={this.state.filter_val}
                                />
                        </div>
                        <div class='txtContainer'>
                            <TextInput
                                autoCapitalize='none'
                                value={this.state.search}
                                fontFamily='Open Sans'
                                placeholder ={'Search using keyword'}
                                class={'subtxtContainer'}
                                style={{flex:1, outlineWidth:0}}
                                onChangeText={(text) => { this.setState({search: text}); }}
                            />
                        </div>
                          <button class="searchclass" onClick={()=>this.searchIt(1)}>
                            <GoSearch color={'white'} size={'16'}/>
                            <p style={{marginLeft:'7px', color:'white', fontFamily:'Open Sans', fontSize:'14px'}}>Search</p>
                          </button>
                        <button style={{ width: 120, justifyContent: 'center', alignItems: 'center' ,display:'flex',textDecoration:'none',borderWidth:0}} onClick={()=>this.setState({ advanceSearch: !this.state.advanceSearch })} >
                          <label style={{fontFamily:'Open Sans', fontSize:13}}>{this.state.advanceSearch ? 'Less Search' : 'Advance Search'}</label>
                        </button>
                </div>
            </div>
            )}

*/}


{this.state.advanceSearch && (
  <>
    <div style={{ display:'flex', marginLeft:'10px', marginRight:'100px', flexWrap:'wrap', marginTop:'10px'}}>
    {/*
    <input type="text" placeholder="Any" value={this.state.search_any} onChange={event => {this.setState({search_any: event.target.value}) }}   style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }}/>
    */}
    <input type="text" placeholder="project" value={this.state.project} onChange={event => {this.setState({project: event.target.value}) }}  style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }} />
    <input type="text" placeholder="operation" value={this.state.operation}  onChange={event => {this.setState({operation: event.target.value}) }} style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }} />
    <input type="text" placeholder="foundry" value={this.state.foundry}  onChange={event => {this.setState({foundry: event.target.value}) }}  style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }} />
    <input type="text" placeholder="project" value={this.state.test_name} onChange={event => {this.setState({test_name: event.target.value}) }}   style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }}/>
    <input type="text" placeholder="test_number" value={this.state.test_number}  onChange={event => {this.setState({test_number: event.target.value}) }}  style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }}/>
    </div>
    <div style={{ display:'flex', marginLeft:'10px', marginRight:'100px', flexWrap:'wrap', marginTop:'20px'}}>
    <input type="text" placeholder="test_type" value={this.state.test_type}  onChange={event => {this.setState({test_type: event.target.value}) }}  style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }}/>
    <input type="text" placeholder="file_id" value={this.state.file_id}   onChange={event => {this.setState({file_id: event.target.value}) }} style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }} />
    <input type="text" placeholder="lot_status" value={this.state.lot_status}  onChange={event => {this.setState({lot_status: event.target.value}) }}  style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }} />
    <input type="text" placeholder="error_cause" value={this.state.error_cause} onChange={event => {this.setState({error_cause: event.target.value}) }}  style={{marginLeft:10, flex:1, padding:10, borderRadius: 4, borderColor: 'grey', borderWidth: 0.5 ,outlineWidth:0, fontFamily: "Qualcomm Next" }}/>
      <button style={{display:'flex',textDecoration:'none',borderWidth:0,marginLeft:'10px',flexDirection:'row',alignItems:'center', justifyContent:'center',backgroundColor: this.state.searchOn_extended ? '#3253DC' : '#6f86e7', height:35,borderRadius:24, flex:1, }} onClick={()=>this.searchIt_extended(1)}>
        <GoSearch color={'white'} size={'16'}/>
        <p style={{marginLeft:'7px', color:'white', fontFamily:'Qualcomm Next', fontSize:'14px'}}>Search</p>
      </button>

      <button style={{display:'flex',textDecoration:'none',borderRadius:24,height:35, marginLeft: '10px', width: 100, borderWidth: 1, borderColor: 'grey', justifyContent: 'center', alignItems: 'center' }} onClick={()=>this.setState({ advanceSearch: !this.state.advanceSearch })} >
        <label style={{fontFamily:'Qualcomm Next', fontSize:13}}>{this.state.advanceSearch ? 'Less Search' : 'Advance Search'}</label>
      </button>

      {this.state.searchOn_extended && (
        <button style={{display:'flex',textDecoration:'none',borderWidth:0,marginLeft:'10px',flexDirection:'row',alignItems:'center', justifyContent:'center',backgroundColor:'#3253DC', height: 35,borderRadius:24, flex:1, }} onClick={()=>this.clearsearch_extended()}>
          <p style={{marginLeft:'7px', color:'white', fontFamily:'Qualcomm Next', fontSize:'14px'}}>Clear Search</p>
        </button>
      )}
    </div>
  </>
)}



          <div style={{ marginLeft: 20 }}>
             <h3 style={{ fontFamily:'Qualcomm Next' }}>
               File Upload
             </h3>
             <div style={{ display: 'flex',  flexDirection: 'row', alignItems: 'center' }}>
                 <input type="file" name="myFile" onChange={this.onFileChange} />
                 <button onClick={this.onFileUpload} style={{ width: 100, backgroundColor: '#3253DC', height: 35,borderRadius:24, justifyContent: 'center', alignItems: 'center' , display:'flex', borderWidth:0, textDecoration:'none'}}>
                   <span style={{ color: 'white'}} > Upload!</span>
                 </button>
             </div>
           {/*this.fileData()*/}
         </div>



            {/* displaying search counts */}
            {(this.state.searchOn_extended || this.state.searchOn_normal)  && (
              <div style={{ padding: 20 }}>Total {this.state.searchTotalCount} results found</div>
            )}

            {/* displaying loader */}
            {this.state.loading && (
              <p style={{ fontFamily:'Qualcomm Next', textAlign: 'center', fontWeight: 'bold' }}>Loading..</p>
            )}

            {/* footer , update button , back button , next button  */}
            {this.state.dataType.length > 0 && (
              <div style={{ display:'flex', flexDirection:'row', justifyContent: 'flex-end', padding: 20 }}>
                    <div style={{ flex: 1, display:'flex' }}>

                    <button onClick={()=>this.updateSelected()} style={{ width: 100, backgroundColor: '#3253DC', height: 35,borderRadius:24, justifyContent: 'center', alignItems: 'center' , display:'flex', borderWidth:0, textDecoration:'none'}} >
                      <label style={{color:'white', fontFamily:'Qualcomm Next', fontSize:15}}>Update</label>
                    </button>

                    </div>

                    <div class="back-next">
                    {this.state.pageNumber > 1 && (
                      <button style={{backgroundColor: '#3253DC',height:35, width:100,  alignItems:'center', justifyContent:'center',borderRadius:24, textDecoration:'none', borderWidth:0, display:'flex'}}  onClick={()=>this.getPreviousPage()}>
                        <label style={{color:'white', fontFamily:'Qualcomm Next', fontSize:13}}>Back</label>
                      </button>
                    )}

                    <button style={{backgroundColor: '#3253DC',height:35,borderRadius:24, width:100, alignItems:'center', justifyContent:'center', marginLeft: 20,textDecoration:'none', borderWidth:0, display:'flex'}}  onClick={()=>this.getNextPage()} >
                      <label style={{color:'white',fontFamily:'Qualcomm Next', fontSize:13}}>Next</label>
                    </button>
                  </div>
              </div>
            )}
          {/* footer ends here */}

            {/* data table */}
            <div style={{ width: '96%',zIndex:999, paddingLeft: '20px',marginTop:'20px', marginBottom:'100px'}}>
                <DataTable
                columns={columns}
                data={this.state.dataType}
                pagination={false}
                striped={true}
                style={{ fontFamily:'Qualcomm Next',width: '80%'}}
                highlightOnHover={true}
                pointerOnHover={false}//SJ -13/07/2020- To remove pointer (hand icon from row items)
                noHeader={false}
                scrollable={true}
                responsive={true}
                defaultSortAsc={false}
                customStyles={customStyles2}
                />
            </div>

            {/* footer , update button , back button , next button  */}

            {this.state.dataType.length > 0 && (
              <div style={{display:'flex', flexDirection:'row', justifyContent: 'flex-end', padding: 20 }}>
              {/*
                  <div style={{display:'flex', flex: 4, flexDirection: 'row', alignItems: 'center', paddingLeft: 10   }}>
                      <button style={{display:'flex', borderWidth:0, textDecoration:'none', width: 100, backgroundColor: '#3253DC', height: 40, justifyContent: 'center', alignItems: 'center' }} onClick={()=>this.updateSelected()}>
                        <label style={{color:'white', fontFamily:'Open Sans', fontSize:13}}>Update</label>
                      </button>
                  </div>
            */}
                <div class="back-next">
                  {this.state.pageNumber > 1 && (
                    <button style={{display:'flex', borderWidth:0, textDecoration:'none',backgroundColor: '#3253DC',height: 35,borderRadius:24, width:100, alignItems:'center', justifyContent:'center'}}  onClick={()=>this.getPreviousPage()}>
                      <label style={{color:'white', fontFamily:'Qualcomm Next', fontSize:13}}>Back</label>
                    </button>
                  )}
                  <button style={{display:'flex', borderWidth:0,borderRadius:24, textDecoration:'none',backgroundColor: '#3253DC',height: 35, width:100,  alignItems:'center', justifyContent:'center', marginLeft: 20}}  onClick={()=>this.getNextPage()} >
                    <label style={{color:'white',fontFamily:'Qualcomm Next', fontSize:13}}>Next</label>
                  </button>
                </div>
            </div>
            )}
          {/* footer ends here */}



           <Modal
            isOpen={this.state.updateModal}
            onRequestClose={()=>this.setState({ updateModal: false })}
            style={customStyles}
            contentLabel="Example Modal"
          >
          {this.state.columnEditable === 'enable_ml_config' && (
            <>
            <div>
            <input type="text" maxlength="1" class='modal-input' value={this.state.enable_ml_config} onChange={event => { this.setState({enable_ml_config: event.target.value }) }}  />

            </div>
            <div style={{flexDirection:'row', display:'flex'}}>
            <button style={{display:'flex', borderWidth:0, textDecoration:'none',backgroundColor:'#3253DC',marginTop:10, marginLeft:0, alignItems:'center', justifyContent:'center', height:35, width:100, borderRadius:24}} onClick={()=>this.confirmupdate_beforeUpdate('enable_ml_config','enable_ml_config','text')}>
            <label style={{color:'white',fontFamily:'Qualcomm Next', fontSize:15}}>Update</label>
            </button>

            <button onClick={()=>this.setState({ updateModal: false })} style={{display:'flex', borderWidth:0, textDecoration:'none',backgroundColor:'#3253DC',marginLeft:10,marginTop:10, marginLeft:5, alignItems:'center', justifyContent:'center', height:35, width:100, borderRadius:24}} >
            <label style={{color:'white',fontFamily:'Qualcomm Next', fontSize:15}}>Cancel</label>
            </button>
            </div>
            </>
            )}

           {this.state.columnEditable === 'enable_pipeline_config' && (
              <>
                <div>
                  <input type="text" maxlength="1" class='modal-input' value={this.state.enable_pipeline_config} onChange={event => { this.setState({enable_pipeline_config: event.target.value }) }} />
                </div>
                <div style={{flexDirection:'row', display:'flex'}}>

                <button style={{display:'flex', borderWidth:0, textDecoration:'none',backgroundColor:'#3253DC',marginTop:10, marginLeft:5, alignItems:'center', justifyContent:'center', height:35, width:100, borderRadius:24}} onClick={()=>this.confirmupdate_beforeUpdate('enable_pipeline_config','enable_pipeline_config','text')}>
                  <label style={{color:'white',fontFamily:'Qualcomm Next', fontSize:15}}>Update</label>
                </button>
                <button onClick={()=>this.setState({ updateModal: false })} style={{display:'flex', borderWidth:0, textDecoration:'none',backgroundColor:'#3253DC',marginLeft:10,marginTop:10, marginLeft:5, alignItems:'center', justifyContent:'center', height:35, width:100, borderRadius:24}} >
                <label style={{color:'white',fontFamily:'Qualcomm Next', fontSize:15}}>Cancel</label>
                </button>
                </div>
            </>
           )}

           {this.state.columnEditable === 'enable_sql_filter' && (
              <>
                <div>
                  <input type="text" maxlength="1"  class='modal-input' value={this.state.enable_sql_filter} onChange={event => { this.setState({enable_sql_filter: event.target.value }) }} />
                </div>
                <div style={{flexDirection:'row', display:'flex'}}>

                <button style={{display:'flex', borderWidth:0, textDecoration:'none',backgroundColor:'#3253DC',marginTop:10, marginLeft:5, alignItems:'center', justifyContent:'center', height:35, width:100, borderRadius:24}} onClick={()=>this.confirmupdate_beforeUpdate('enable_sql_filter','enable_sql_filter','text')}>
                  <label style={{color:'white',fontFamily:'Qualcomm Next', fontSize:15}}>Update</label>
                </button>
                <button onClick={()=>this.setState({ updateModal: false })} style={{display:'flex', borderWidth:0, textDecoration:'none',backgroundColor:'#3253DC',marginLeft:10,marginTop:10, marginLeft:5, alignItems:'center', justifyContent:'center', height:35, width:100, borderRadius:24}} >
                <label style={{color:'white',fontFamily:'Qualcomm Next', fontSize:15}}>Cancel</label>
                </button>
                </div>
            </>
           )}



          </Modal>



        <Toaster position="top-center" reverseOrder={false} />
        <ReactTooltip />
       </div>
    );
  }
}

const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
  },
};
